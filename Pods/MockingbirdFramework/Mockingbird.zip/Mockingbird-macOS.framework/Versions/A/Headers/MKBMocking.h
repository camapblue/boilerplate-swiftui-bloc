//
//  MKBMocking.h
//  MockingbirdFramework
//
//  Created by typealias on 7/17/21.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

id MKBMock(id aType);

id MKBMockClass(Class aClass);
id MKBMockProtocol(id aProtocol);

NS_ASSUME_NONNULL_END
